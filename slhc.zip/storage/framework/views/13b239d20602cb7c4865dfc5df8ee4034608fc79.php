<?php $__env->startSection('title', 'Alternative Medicine - Markham, Stouffville'); ?>
<?php $__env->startSection('meta-description-content', 'Our practice revolves around the ancient healing arts of traditional healing.'); ?>

<?php $__env->startSection('content'); ?>

<h3 class="text-center mb-5">Find out What Our Clients Say About Us</h3>

<div class="container-fluid my-5" style="background-color: black; color: #fff;">
    <div class="container">
        <div class="row ">
            <div class="col-md-4 align-self-center">
                <h4>LEAVE US A REVIEW TODAY</h4>
            </div>
            <div class="col-md-8 py-5 align-self-center">
                <form action="/testimonials" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label" for="fname">First Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control  <?php echo e($errors->has('fname') ? ' is-invalid' : ''); ?>" id="fname" name="fname" placeholder="John" value="<?php echo e(old('fname')); ?>">
                                    <?php if($errors->has('fname')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('fname')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label" for="lname">Last Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control <?php echo e($errors->has('lname') ? ' is-invalid' : ''); ?>" id="lname" name="lname" placeholder="Doe"value="<?php echo e(old('lname')); ?>">
                                    <?php if($errors->has('lname')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('lname')); ?></strong>
                                        </span>
                                    <?php endif; ?>        
                            </div>
                        </div>
                    
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label" for="review">Review</label>
                            <div class="col-sm-10">
                                <textarea class="form-control <?php echo e($errors->has('review') ? ' is-invalid' : ''); ?>" id="review" name="review" aria-describedby="emailHelp" placeholder="The service was..."><?php echo e(old('review')); ?></textarea>
                                    <?php if($errors->has('review')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('review')); ?></strong>
                                        </span>
                                    <?php endif; ?>    
                            </div>
                        </div>
                        
                        <input class="form-check-input " type="hidden" value="" name="verified">

                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <?php if($reviews): ?>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($review->verified): ?>
                <div class="testimonial col-md-4">
                    <p class="name py-0 my-0 font-weight-bold"><?php echo e($review->fname); ?> <?php echo e($review->lname); ?></p>
                    <p class="date"><?php echo e(date_format($review->created_at, 'd/M/Y')); ?></p>
                    <p class="content font-italic"><?php echo e($review->review); ?></p>
                    <hr class="py-3">
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/pages/testimonials.blade.php ENDPATH**/ ?>