<?php $__env->startSection('title', 'Alternative Medicine - Markham, Stouffville'); ?>
<?php $__env->startSection('meta-description-content', 'Our practice revolves around the ancient healing arts of traditional healing.'); ?>

<?php $__env->startSection('content'); ?>
        <div class="container">
                <div class="row">
                        <div class="col-12">
                                <?php if($service): ?>
                                        <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
        
                                                <div class="col-md-4">
                                                    <img class="img-fluid" src=<?php echo e(asset("storage/" . $service_item->image)); ?>>
                                                </div>
                                                <div class="col-md-8">
                                                        <h2 class="my-0"><?php echo e($service_item->service_name); ?></h2>
                                                        <h3 class="my-0"><?php echo e($service_item->service_chinese_name); ?></h3>
                                                        <p> <?php echo e($service_item->detailed_description); ?></p>
                                                        <div class="text-right">
                                                             <div>$<?php echo e(number_format($service_item->service_price, 2)); ?>/ <?php echo e($service_item->duration); ?>mins
                                                        </div>
                                                        <div><a href="/book-now"><button class="btn btn-primary">Book Now</button></a></div>
                                                        </div>
                                                </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </div>
                </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/pages/services/subpage/index.blade.php ENDPATH**/ ?>