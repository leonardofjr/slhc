<?php $__env->startSection('content'); ?>
    <div class="card-header">
        <h2><?php echo e(\Request::route()->getName()); ?></h2>
    </div>

   
    <form id="service_form_create" class="p-4" action="/services" method="POST">
        <div id="uploadImageModal" class="modal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="upload-demo"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary crop-upload-image">Crop & Upload Image</button>
                </div>
                </div>
            </div>
        </div>
        <?php echo e(csrf_field()); ?>


        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="service_name">Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control <?php echo e($errors->has('service_name') ? ' is-invalid' : ''); ?>" id="service_name" name="service_name" value="<?php echo e(old('service_name')); ?>"  placeholder="Enter name">
                 <?php if($errors->has('service_name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('service_name')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>

      
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="service_chinese_name">Chinese name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control <?php echo e($errors->has('service_chinese_name') ? ' is-invalid' : ''); ?>" id="service_chinese_name" name="service_chinese_name" value="<?php echo e(old('service_chinese_name')); ?>"  placeholder="Enter the chinese name for the service">
                 <?php if($errors->has('service_chinese_name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('service_chinese_name')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>

      


        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="service_image_file">Image</label>
            <div class="col-sm-10">
                <input type="file" class="form-control <?php echo e($errors->has('service_image_file') ? ' is-invalid' : ''); ?>" id="service_image_file" name="service_image_file" >
                <?php if($errors->has('service_image_file')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('service_image_file')); ?></strong>
                </span>
             <?php endif; ?>
                <img class="service_image_preview my-3" src="" alt="Preview of image">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="service_duration">Duration</label>
            <div class="col-sm-4">
                <select type="dropdown" class="form-control <?php echo e($errors->has('service_duration') ? ' is-invalid' : ''); ?>" id="service_duration" name="service_duration"  placeholder="Hour">
                    <option value="" selected> Choose...</option>
                    <?php $__currentLoopData = $durationDropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $durationDropdownItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($durationDropdownItem["duration"]); ?>" <?php echo e(old('service_duration') == $durationDropdownItem["duration"]  ? "selected" : ""); ?>><?php echo e(gmdate("H:i:s",$durationDropdownItem["duration"])); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('service_duration')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('service_duration')); ?></strong>
                    </span>
                    <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="service_price">Price</label>
            <div class="col-sm-10">
                <input type="number" class="form-control <?php echo e($errors->has('service_price') ? ' is-invalid' : ''); ?>" id="service_price" name="service_price" value="<?php echo e(old('service_price')); ?>"  placeholder="20.00">
                 <?php if($errors->has('service_price')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('service_price')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="short_description">Short Description</label>
            <div class="col-sm-10">
                <textarea class="form-control <?php echo e($errors->has('short_description') ? ' is-invalid' : ''); ?>" id="short_description" name="short_description" value="<?php echo e(old('short_description')); ?>"  placeholder="Enter a short description"><?php echo e(old('short_description')); ?></textarea>
                 <?php if($errors->has('short_description')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('short_description')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="detailed_description">Detailed Description</label>
            <div class="col-sm-10">
                <textarea class="form-control <?php echo e($errors->has('detailed_description') ? ' is-invalid' : ''); ?>" id="detailed_description" name="detailed_description"   placeholder="Enter a description"><?php echo e(old('detailed_description')); ?></textarea>
                 <?php if($errors->has('detailed_description')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('detailed_description')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>

            <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'short_description' );
                CKEDITOR.replace( 'detailed_description' );
            </script>         
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\html\slhc\resources\views/backend/services/subpages/create.blade.php ENDPATH**/ ?>