<?php $__env->startSection('content'); ?>
    <div class="card-header">
        <h2><?php echo e(\Request::route()->getName()); ?></h2>
    </div>
    <form class="p-4" action="/reviews" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="fname">First Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control  <?php echo e($errors->has('fname') ? ' is-invalid' : ''); ?>" id="fname" name="fname" placeholder="John" value="<?php echo e(old('fname')); ?>">
                    <?php if($errors->has('fname')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('fname')); ?></strong>
                        </span>
                     <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="lname">Last Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control <?php echo e($errors->has('lname') ? ' is-invalid' : ''); ?>" id="lname" name="lname" placeholder="Doe"value="<?php echo e(old('lname')); ?>">
                    <?php if($errors->has('lname')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('lname')); ?></strong>
                        </span>
                     <?php endif; ?>        
            </div>
        </div>
      
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="review">Review</label>
            <div class="col-sm-10">
                <textarea class="form-control <?php echo e($errors->has('review') ? ' is-invalid' : ''); ?>" id="review" name="review" aria-describedby="emailHelp" placeholder="The service was..."><?php echo e(old('review')); ?></textarea>
                    <?php if($errors->has('review')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('review')); ?></strong>
                        </span>
                     <?php endif; ?>    
            </div>
        </div>
        
        <div class="form-check">
            <input class="form-check-input " type="checkbox" value="verified" id="verfied" name="verified">
            <label class="form-check-label" for="verfied">
                Verfieid
            </label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\html\slhc\resources\views/backend/reviews/subpages/create.blade.php ENDPATH**/ ?>