<?php $__env->startSection('title', 'Alternative Medicine - Markham, Stouffville'); ?>
<?php $__env->startSection('meta-description-content', 'Our practice revolves around the ancient healing arts of traditional healing.'); ?>

<?php $__env->startSection('content'); ?>
        <div class="container">
                <div class="row">
                        <div class="col-12">
                                <?php if($services): ?>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row p-3 border m-3">
                                                <div class="col-md-4">
                                                        <img class="img-fluid" src=<?php echo e(asset("storage/" . $service->image)); ?>>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <h2 class="my-0"><?php echo e($service->service_name); ?></h2>
                                                        <h3 class="my-0"><?php echo e($service->service_chinese_name); ?></h3>
                                                        <p> <?php echo $service->detailed_description; ?></p>
                                                        <div class="text-right">
                                                                <div class="h3">$<?php echo e(number_format($service->service_price, 2)); ?> /
                                                                        <?php if(floor($service->duration / 3600  * 60 / 60) < 1): ?>
                                                                          <?php echo e(floor($service->duration / 3600  * 60)); ?>mins
                                                                        <?php else: ?>
                                                                          <?php echo e(floor($service->duration / 3600  * 60 / 60)); ?>HR
                                                                        <?php endif; ?>
                                                        </div>
                                                        <div><a href="/book-now"><button class="btn btn-primary">Book Now</button></a></div>
                                                        </div>
                                                </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </div>
                </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/pages/services/index.blade.php ENDPATH**/ ?>