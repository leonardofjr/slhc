<li class="item"><a href="<?php echo e(route("Who Are We")); ?>">Who Are We</a></li>
<li class="item"><a href="<?php echo e(route("Treatments")); ?>">Treatments</a></li>
<li class="item"><a href="<?php echo e(route("Testimonials")); ?>">Testimonials</a></li>
<li class="item"><a href="<?php echo e(route("Contact")); ?>">Contact</a></li>
<li class="item book_now"><a href="<?php echo e(route("Book Now")); ?>">Book Now</a></li><?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/menus/primary-menu.blade.php ENDPATH**/ ?>