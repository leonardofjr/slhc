<section class="top-footer container py-5">
    <div class="row">
        <div class="col-md-4 col-12">
            <div class="mb-2">
                <a  href="/"><?php echo $__env->make('../svgs/logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
            </div>
            <p>Strengthen your power, acheieve balance, awaken your energy, rejuvenate your soul, revive your spirit
            </p>

            <div>
                <h5>REACH US OUT AT SOCIAL MEDIA</h5>
                <?php if($facebook): ?>
                    <a href="<?php echo e($facebook); ?>"><i class="fab fa-facebook fa-2x mr-2"></i></a>
                <?php endif; ?>
                <?php if($facebook): ?>
                   <a href="<?php echo e($instagram); ?>"><i class="fab fa-instagram fa-2x"></i></a>
                <?php endif; ?>
            </div>
            <div class="mt-4">
                <a href="<?php echo e($facebook); ?>">
                    <img src="<?php echo e(asset('imgs/facebook-profile-image.png')); ?>" class="img-fluid" alt="">
                </a>
            </div>

        </div>
        <div class="col-md-4 col-12">
            <h5>NAVIGATION</h5>
            <ul>
                <?php echo $__env->make('frontend.menus.primary-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>

        </div>

     
        <div class="col-md-4 col-12">
            <h5>CONTACT</h5>
            <?php echo $__env->make('frontend.pages.partials.contact-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('frontend.components.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
</section>

<?php echo $__env->make('frontend.pages/partials/site-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/components/footer.blade.php ENDPATH**/ ?>