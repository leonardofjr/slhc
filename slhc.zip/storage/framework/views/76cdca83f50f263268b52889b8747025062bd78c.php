<?php $__env->startSection('title', 'Alternative Medicine - Markham, Stouffville'); ?>
<?php $__env->startSection('meta-description-content', 'Our practice revolves around the ancient healing arts of traditional healing.'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="pb-3">
            <h4 class="text-center">Find out more information</h4>
            <p class="text-center">If you would like to discuss our treatments, please contact us and we will be happy to provide with the information you need.</p>
        </div>
        <div class="row">
            <div class="col-sm-5">
                <h4>Address</h4>
                 <h6><?php echo e($company_name); ?></h6>
                <p>Phone: <?php echo $__env->make('frontend.pages.partials.phone-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></p>
                <p>Email: <?php echo $__env->make('frontend.pages.partials.email-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></p>
                    <a href="https://goo.gl/maps/zEyD95aCnfF2"> <?php echo e($company_address); ?>, <br><?php echo e($company_city); ?>, <?php echo e($company_territory); ?>,<br><?php echo e($company_postal_code); ?></a>

                <?php echo $__env->make('frontend.components.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>


            <div class="col-sm-7 ">
                <h4>Ask a question</h4>
                <?php echo $__env->make('frontend.components/contact-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>