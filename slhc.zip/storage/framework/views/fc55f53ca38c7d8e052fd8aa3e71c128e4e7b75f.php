<div class="row py-5">
    <!-- Card 1 -->
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-container col-12 col-sm-6 col-md-3 col-lg-3">
            <div class="flip-container" ontouchstart="this.classList.toggle('hover');">
                <div class="flipper">
                    <!-- front content -->
                    <div class="front" style='background-image: url("<?php echo e(file_exists('storage/png') ? asset("storage/" . $service_item->image) : asset("imgs/" . $service_item->image)); ?>");'>
                        <div class="content">
                            <h2> <?php echo e($service_item->service_chinese_name); ?> <br> <hr class="lf-line"> <?php echo e($service_item->service_name); ?></h2>
                            <hr>   
                                <div class="text-center h5" style="color:white">$<?php echo e(number_format($service_item->service_price, 2)); ?> /
                                    <?php if(floor($service_item->duration / 3600  * 60 / 60) < 1): ?>
                                    <?php echo e(floor($service_item->duration / 3600  * 60)); ?>mins
                                    <?php else: ?>
                                    <?php echo e(floor($service_item->duration / 3600  * 60 / 60)); ?>HR
                                    <?php endif; ?>
                                </div>
                        </div>
                        <!-- front content -->
                    </div>
                    <!-- back content -->
                    <div class="back text-center">
                        <div class="content">
                            <h2><?php echo e($service_item->service_chinese_name); ?> <br> <hr class="lf-line"><?php echo e($service_item->service_name); ?></h2>
                            <p><?php echo $service_item->short_description; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       <?php if($key === 3): ?>) {
           <?php break; ?>;
       }
       <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</div><?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/components/flip-cards.blade.php ENDPATH**/ ?>