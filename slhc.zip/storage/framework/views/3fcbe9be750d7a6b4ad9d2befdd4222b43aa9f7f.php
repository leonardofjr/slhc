<?php $__env->startSection('title', 'Alternative Medicine - Markham, Stouffville'); ?>
<?php $__env->startSection('meta-description-content', 'Our practice revolves around the ancient healing arts of traditional healing.'); ?>

<?php $__env->startSection('content'); ?>
        <div class="container">
                <div class="row">
                        <div class="col-12">
                                <?php if($services): ?>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
        
                                                <div class="col-md-9">
                                                        <h2><a href="/treatments/<?php echo e($service->slug); ?>"><?php echo e($service->service_name); ?></a></h2>
                                                        <p> <?php echo e($service->short_description); ?></p>
                                                </div>
                                                <div class="col-md-3 d-flex align-items-end justify-content-end">
                                                        <div class="text-right">
                                                        <div>$<?php echo e(number_format($service->service_price, 2)); ?>/ <?php echo e($service->duration); ?>mins</div>
                                                        <div><a href="/book-now"><button class="btn btn-primary">Book Now</button></a></div>
                                                        </div>
                                                </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </div>
                </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/pages/treatments.blade.php ENDPATH**/ ?>