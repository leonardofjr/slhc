<?php $__env->startSection('content'); ?>

                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-header">
                        <h2><?php echo e(\Request::route()->getName()); ?></h2>
                    </div>

                    <div class="p-4">
                        You are logged in!
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\html\slhc\resources\views/backend/dashboard/index.blade.php ENDPATH**/ ?>