
    <form action="/book-now" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="form-group row">
                <div class="col-sm-12">
                    <input type="text" class="form-control  <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" id="name" name="name" placeholder="Name" value="<?php echo e(old('name')); ?>">
                        <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                </div>

            </div>

            <div class="form-group row">
                <div class="col-sm-12">
                    <input type="tel" class="form-control  <?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" id="phone" name="phone" placeholder="Phone"  value="<?php echo e(old('phone')); ?>">
                        <?php if($errors->has('phone')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('phone')); ?></strong>
                            </span>
                        <?php endif; ?>
                </div>

            </div>
            <div class="form-group row">

                <div class="col-sm-12">
                    <input type="email" class="form-control  <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                </div>
            </div>

        <div class="form-group ">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="<?php echo e($service["service_name"]); ?>" value="<?php echo e($service["service_name"]); ?>" name="interests[]">
                <label class="form-check-label" for="<?php echo e($service["service_name"]); ?>"><?php echo e($service["service_name"]); ?></label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
            <div class="form-group row">

                <div class="col-sm-12">
                    <input type="date" class="form-control  <?php echo e($errors->has('date') ? ' is-invalid' : ''); ?>" id="date" name="date" placeholder="Email" value="<?php echo e(old('date')); ?>">
                        <?php if($errors->has('date')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('date')); ?></strong>
                            </span>
                        <?php endif; ?>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-12">
                    <textarea class="form-control <?php echo e($errors->has('message') ? ' is-invalid' : ''); ?>" id="message" name="message" aria-describedby="emailHelp" placeholder="Message"><?php echo e(old('message')); ?></textarea>
                        <?php if($errors->has('message')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('message')); ?></strong>
                            </span>
                        <?php endif; ?>    
                </div>
            </div>

        <div class="form-group">
            <div class="g-recaptcha" data-sitekey="6LcFrGoUAAAAAE9nwReZ-oKM5nff7vL3AiLw_Uo1"></div>
        </div>
        <div class="flash-message-recaptcha-token alert alert-info d-none">
            <span></span>
        </div> 
            <button type="submit" class="btn btn-primary">SEND MESSAGE</button>
        </form>
<?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/components/book-now-form.blade.php ENDPATH**/ ?>