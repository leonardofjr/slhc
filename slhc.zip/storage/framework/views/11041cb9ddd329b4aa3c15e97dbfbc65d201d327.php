<a href="tel:<?php echo e($company_phone); ?>"> <?php echo e($company_phone); ?></a>
<?php /**PATH C:\wamp64\www\html\slhc\resources\views/frontend/pages/partials/phone-link.blade.php ENDPATH**/ ?>