<?php $__env->startSection('content'); ?>
<div class="card-header">
    <h2><?php echo e(\Request::route()->getName()); ?></h2>
</div>
<div class="p-4">
<hr>
<h5>Company Profile</h5>
<hr>
<form action="/settings" method="POST">    
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="_method" value="put" />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="company_name">Company Name</label>
            <div class="col-sm-10">
            <input type="text" value="<?php echo e($data->company_name); ?>" class="form-control <?php echo e($errors->has('company_name') ? ' is-invalid' : ''); ?>" id="company_name" name="company_name" >
            <?php if($errors->has('company_name')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('company_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="phone">Phone</label>
            <div class="col-sm-10">
                <input type="phone"  value="<?php echo e($data->phone); ?>"  class="form-control <?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" id="phone" name="phone">
               <?php if($errors->has('phone')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('phone')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
      
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="email">Email</label>
            <div class="col-sm-10">
                <input type="text"  value="<?php echo e($data->email); ?>"  class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="email" name="email">
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
      
      
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="street_address">Street Address</label>
            <div class="col-sm-10">
                <input type="text"  value="<?php echo e($data->street_address); ?>"  class="form-control <?php echo e($errors->has('street_address') ? ' is-invalid' : ''); ?>" id="street_address" name="street_address">
                <?php if($errors->has('street_address')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('street_address')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
      
      
      
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="city">City</label>
            <div class="col-sm-10">
                <input type="text"  value="<?php echo e($data->city); ?>"  class="form-control <?php echo e($errors->has('city') ? ' is-invalid' : ''); ?>" id="city" name="city">
                <?php if($errors->has('city')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('city')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
      
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="province">Province</label>
            <div class="col-sm-10">
                <input type="text"  value="<?php echo e($data->province); ?>"  class="form-control <?php echo e($errors->has('province') ? ' is-invalid' : ''); ?>" id="province" name="province">
                <?php if($errors->has('province')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('province')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
      
      
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="postal_code">Postal Code</label>
            <div class="col-sm-10">
                <input type="text"  value="<?php echo e($data->postal_code); ?>"  class="form-control <?php echo e($errors->has('postal_code') ? ' is-invalid' : ''); ?>" id="province" name="postal_code">
                <?php if($errors->has('postal_code')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('postal_code')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
      

        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="facebook">Facebook</label>
            <div class="col-sm-10">
                <input type="text"  value="<?php echo e($data->facebook); ?>"  class="form-control <?php echo e($errors->has('facebook') ? ' is-invalid' : ''); ?>" id="facebook" name="facebook">
                <?php if($errors->has('facebook')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('facebook')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
      
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="instagram">Instagram</label>
            <div class="col-sm-10">
                <input type="text"  value="<?php echo e($data->instagram); ?>"  class="form-control <?php echo e($errors->has('instagram') ? ' is-invalid' : ''); ?>" id="instagram" name="instagram">
                <?php if($errors->has('instagram')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('instagram')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>

        <div class="my-4">
        <hr>
        <h5>Hours of Operation</h2>
        <table class="table">
        <tr>
            <th>Day</th>
            <th>Open</th>
            <th>Close</th>
        </tr>
        <?php $__currentLoopData = $hoursOfOperation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(jddayofweek($item->day, 1)); ?></td>
                <td><input type="time" value="<?php echo e($item->start); ?>" name="start[]"></td>
                <td><input type="time" value="<?php echo e($item->end); ?>" name="end[]"></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
</form>
</div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\html\slhc\resources\views/backend/settings/index.blade.php ENDPATH**/ ?>