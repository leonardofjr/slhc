<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DurationDropdown extends Model
{
    //
}
