<li class="item"><a href="{{route("Who Are We")}}">Who Are We</a></li>
<li class="item"><a href="{{route("Treatments")}}">Treatments</a></li>
<li class="item"><a href="{{route("Testimonials")}}">Testimonials</a></li>
<li class="item"><a href="{{route("Contact")}}">Contact</a></li>
<li class="item book_now"><a href="{{route("Book Now")}}">Book Now</a></li>