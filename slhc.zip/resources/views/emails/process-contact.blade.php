<p>Name: {{$name}}</p>
<p>Email: {{$email}}</p>
<p>Message: {{$inquiry}}</p>
<small>This mail is sent via contact form on sacredlighthealing.ca</small>