<div class="content-header  mb-3">
            <h1><?php echo Route::current()->getName();?></h1>
</div>