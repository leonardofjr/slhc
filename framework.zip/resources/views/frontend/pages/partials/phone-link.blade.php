<a href="tel:{{$company_phone}}"> {{$company_phone}}</a>
