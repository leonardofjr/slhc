@extends('layouts.page')

@section('title', 'Sacred Light Healing Centre')

@section('content')



<div class="row">

    <div class="col-9">

        

    </div>
btn btn-primary
</div>



<p>1 Day a week – 1.5 Hrs</p>

<p>get all course materials when you enroll. Classes will be taught at Angus Glen Community Center. Enroll Today</p>

<p>Next Class Scheduled For June 5th 2018</p>



<div class="text-right">

    <a href="tel:{{$company_phone}}"><button class="lf-primary-button">CALL {{$company_phone}} TO ENROLL </button></a>

</div>

@endsection