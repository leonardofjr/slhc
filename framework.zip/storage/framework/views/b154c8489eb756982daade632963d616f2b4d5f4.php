<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/emails/process-book-now.blade.php */ ?>
<p>Name: <?php echo e($name); ?></p>

<p>Phone: <?php echo e($phone); ?></p>

<p>Email: <?php echo e($email); ?></p>

<p>What are you looking for?:<ul> <?php $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li> <?php echo e($interest); ?> </li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </ul></p>

<p>Preferred Date: <?php echo e($date); ?></p>

<p>Message: <?php echo e($inquiry); ?></p>

<small>This mail is sent via book form on sacredlighthealing.ca</small>