<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/emails/process-contact.blade.php */ ?>
<p>Name: <?php echo e($name); ?></p>
<p>Email: <?php echo e($email); ?></p>
<p>Message: <?php echo e($inquiry); ?></p>
<small>This mail is sent via contact form on sacredlighthealing.ca</small>