<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/pages/partials/phone-link.blade.php */ ?>
<a href="tel:<?php echo e($company_phone); ?>"> <?php echo e($company_phone); ?></a>
