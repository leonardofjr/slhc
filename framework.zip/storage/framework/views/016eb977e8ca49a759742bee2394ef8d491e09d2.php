<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/pages/testimonials.blade.php */ ?>
<?php $__env->startSection('title', 'Testimonials - Sacred Light Healing Centre'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
<h5 class="text-center mb-5">Find out What Our Clients Say About Us</h5>
    <div class="row">
        <?php if($reviews): ?>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="testimonial col-md-4">
                <p class="name py-0 my-0 font-weight-bold"><?php echo e($review->fname); ?></p>
                <p class="date"><?php echo e(date_format($review->created_at, 'd/M/Y')); ?></p>
                <p class="content font-italic"><?php echo e($review->review); ?></p>
                <hr class="py-3">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>