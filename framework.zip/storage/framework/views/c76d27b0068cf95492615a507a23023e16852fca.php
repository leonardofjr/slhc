<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/backend/services/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
        <h2><?php echo e(\Request::route()->getName()); ?></h2><a class="btn btn-primary" href="<?php echo e(route("Post Service")); ?>">Add Service</a>

        <table class="table">
        <thead>
        <tr>
        <th scope="col">id</th>
        <th scope="col">Service Name</th>
        <th scope="col">Price</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
        </tr>
        </thead>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tbody>
        <tr>
                <th scope="row"><?php echo e($item->id); ?></th>
                <td><?php echo e($item->service_name); ?></td>
                <td>$<?php echo e($item->service_price); ?></td>
                <td><a href="/services/<?php echo e($item->id); ?>"><i class="fas fa-edit"></i></a></td>
                <td>
                <form action="/services/<?php echo e($item->id); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="delete" />
                                <button type="submit" class="far fa-trash-alt"></button>
                        </form>
                </td>
        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>