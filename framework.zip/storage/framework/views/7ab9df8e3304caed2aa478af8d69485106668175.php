<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/pages/courses.blade.php */ ?>
<?php $__env->startSection('title', 'Sacred Light Healing Centre'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-9">
        
    </div>
</div>

<p>1 Day a week – 1.5 Hrs</p>
<p>get all course materials when you enroll. Classes will be taught at Angus Glen Community Center. Enroll Today</p>
<p>Next Class Scheduled For June 5th 2018</p>

<div class="text-right">
    <a href="tel:<?php echo e($company_phone); ?>"><button class="lf-primary-button">CALL <?php echo e($company_phone); ?> TO ENROLL </button></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>