<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/emails/contact.blade.php */ ?>
<?php $__env->startComponent('mail::message'); ?>
#This message was sent from our contact form

<strong>Name:</strong> <?php echo e($data['name']); ?> <br>
<strong>Email:</strong> <?php echo e($data['email']); ?> <br>
<strong>Message:</strong> <?php echo e($data['message']); ?>


<?php echo $__env->renderComponent(); ?>