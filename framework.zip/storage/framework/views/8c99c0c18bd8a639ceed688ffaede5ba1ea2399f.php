<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/pages/subpages/courses/herbal-medicine-workshop.blade.php */ ?>
<?php $__env->startSection('title', 'Herbal Medicine Workshop - Sacred Light Healing Centre'); ?>
<?php $__env->startSection('content'); ?>
<p>Coming Soon</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>