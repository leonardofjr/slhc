<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/components/navigation.blade.php */ ?>
  <?php if(\Request::is('/')): ?> 

    <nav class="main-navigation d-none d-xl-block d-lg-block d-md-none d-sm-none"> 

    <?php else: ?> 

    <nav class="main-navigation d-none d-xl-block d-lg-block d-md-none d-sm-none" style="position:initial; background-color:black;"> 

  <?php endif; ?>



  <div class="container">

  <div class="row">

      <div class="col-lg-3 col-md-3 col-sm-2 logo">

        <a href="/"><?php echo $__env->make('../svgs/logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>

      </div>

      

    <ul class="col-lg-9  col-md-9 col-sm-10 text-right">

         <?php echo $__env->make('frontend.menus.primary-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </ul>

  </div>

  </div>

</nav>



<nav class="d-block  d-sm-block d-md-block d-lg-none navbar navbar-dark mobile-navigation">

      <div class="row">

        <div class="pt-3 col-9 pl-5">

              <a href="/"><?php echo $__env->make('../svgs/logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>

        </div>

        <div id="hamburger-button-container" class="col-3">

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent">

           <span class="navbar-toggler-icon"></span>

          </button>

        </div>

      </div>





    <div id="navbarToggleExternalContent" class="collapse">

      <ul id="nav-menu">

           <?php echo $__env->make('frontend.menus.primary-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </ul>

    </div>



</nav>





