<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/components/jumbotron.blade.php */ ?>
<?php if(\Request::is('/') || \Request::is('/who-are-we')): ?>
  <div class="jumbotron">

    <?php if(\Request::is('/')): ?>
      <div class="home-cover"></div>
        <span>
          We have a <strong>moral obligation</strong> to help others
        </span>
    <?php endif; ?>

    <?php if(\Request::is('treatments') || \Request::is('treatments/*')): ?>

      <div class="treatments-cover"></div>

    <?php endif; ?>


    <?php if(\Request::is('who-are-we')): ?>

      <div class="who-are-we-cover"></div>

    <?php endif; ?>

  </div>
<?php endif; ?>