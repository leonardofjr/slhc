<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/home.blade.php */ ?>
<?php $__env->startSection('content'); ?>

                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <h2><?php echo e(\Request::route()->getName()); ?></h2>

                    You are logged in!
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>