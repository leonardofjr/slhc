<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/pages/partials/contact-info.blade.php */ ?>
<ul class="p-l pb-4 m-0">
    <li class="pb-2"><i class="fas fa-phone"></i> <span><strong>Phone:</strong></span><?php echo $__env->make('frontend.pages.partials.phone-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></li>
    <li class="pb-2"><i class="fas fa-envelope"></i> <span><strong>Email:</strong></span><?php echo $__env->make('frontend.pages.partials.email-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></li>
<li class="pb-2"><i class="fas fa-map-marker-alt"></i> <span><strong>Address:</strong></span><a href="https://goo.gl/maps/zEyD95aCnfF2"> <?php echo e($company_address); ?>, <?php echo e($company_city); ?>, <?php echo e($company_territory); ?>, <?php echo e($company_postal_code); ?></a></li>
</ul>