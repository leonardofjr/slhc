<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/backend/users/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
        <h2><?php echo e(\Request::route()->getName()); ?></h2><a class="btn btn-primary" href='<?php echo e(route("Add User")); ?>'>Add User</a>

        <table class="table">
        <thead>
        <tr>
        <th scope="col">id</th>
        <th scope="col">First Name</th>
        <th scope="col">Last Name</th>
        <th scope="col">Email</th>
        <th scope="col">Admin</th>
        <th scope="col">User</th>
        <th scope="col">Visitor</th>
        <th scope="col">Edit</th>
        </tr>
        </thead>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tbody>
        <tr>
                <th scope="row"><?php echo e($user->id); ?></th>
                <td><?php echo e($user->fname); ?></td>
                <td><?php echo e($user->lname); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                <input type="checkbox" disabled name="role_admin" <?php echo e($user->hasRole('Admin') ? 'checked' : ''); ?>></td>
                <td>
                 <input type="checkbox" disabled name="role_user" <?php echo e($user->hasRole('User') ? 'checked' : ''); ?>></td>
                 <td>
                <input type="checkbox" disabled name="role_visitor" <?php echo e($user->hasRole('Visitor') ? 'checked' : ''); ?>></td>
                <td><a href="/users/<?php echo e($user->id); ?>"><i class="fas fa-edit"></i></a></td>
        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>