<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/components/contact-form.blade.php */ ?>

   <form action="/contact" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="form-group row">
            <div class="col-sm-6">
                <input type="text" class="form-control  <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" id="name" name="name" placeholder="Name" value="<?php echo e(old('name')); ?>">
                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                     <?php endif; ?>
            </div>

            <div class="col-sm-6">
                <input type="email" class="form-control  <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                     <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-12">
                <textarea class="form-control <?php echo e($errors->has('inquiry') ? ' is-invalid' : ''); ?>" id="inquiry" name="inquiry" aria-describedby="emailHelp" placeholder="Message"><?php echo e(old('inquiry')); ?></textarea>
                    <?php if($errors->has('inquiry')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('inquiry')); ?></strong>
                        </span>
                     <?php endif; ?>    
            </div>
        </div>
        
        <div class="form-group">
            <div class="g-recaptcha " data-size="compact" data-sitekey="6LcFrGoUAAAAAE9nwReZ-oKM5nff7vL3AiLw_Uo1"></div>
        </div>
        <div class="flash-message-recaptcha-token alert alert-info d-none">
            <span></span>
        </div> 
        
        <button type="submit" class="btn btn-primary">SEND MESSAGE</button>
    </form>