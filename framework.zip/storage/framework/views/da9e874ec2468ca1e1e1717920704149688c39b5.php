<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/pages/book-now.blade.php */ ?>
<?php $__env->startSection('title', 'Book Now - Sacred Light Healing Centre'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

    <h5 class="text-center">Ready to book your treatment? </h5>

    <p class="text-center">We are here to help! If you're an old timer and don't feel like booking online, please feel free to call or text us at    <?php echo $__env->make('frontend.pages.partials.phone-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> and we will do our best to accommodate.</p>

<div class="row">
        <div class="col-sm-7">
             <h4>Complete the form below!</h4>
            <?php echo $__env->make('frontend.components/book-now-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div  class="col-sm-5">
                <h4>Time Schedule</h4>
                <?php echo $__env->make('frontend.components.schedule', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
   </div>

</div>

               

        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>