<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/pages/partials/content-header.blade.php */ ?>
<div class="content-header  mb-3">
            <h1><?php echo Route::current()->getName();?></h1>
</div>