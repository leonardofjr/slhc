<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/pages/subpages/courses/acupressure-workshop.blade.php */ ?>
<?php $__env->startSection('title', 'Acupressure Workshop - Sacred Light Healing Centre'); ?>
<?php $__env->startSection('content'); ?>
<h3>ACUPRESSURE LEVEL I</h3>
<p>
Learn the basics of acupressure by joining our certification program you will learn the basis of acupressure and how it can benefit you and you love ones around you.
</p>
<p>
you could learn how to use safe natural techniques on yourself or others we teach you how to self treat yourself with this ancient self healing technique.
</p>

<h3>Requirement</h3>
<ul>
    <li>Interest in learning traditional healing</li>
</ul>

<p>1 Day a week – 1.5 Hrs</p>
<p>get all course materials when you enroll. Classes will be taught at Angus Glen Community Center. Enroll Today</p>
<p>Next Class Scheduled For June 5th 2018</p>

<div class="text-right">
    <a href="tel:<?php echo e($company_phone); ?>"><button class="lf-primary-button">CALL <?php echo e($company_phone); ?> TO ENROLL </button></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>