<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/menus/courses-menu.blade.php */ ?>
    <?php $__currentLoopData = $main_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_page_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($main_page_item['path_name'] === 'Courses'): ?>
             <li class="item"><a href="<?php echo e(url($main_page_item['path_url'])); ?>"><?php echo e($main_page_item['path_name']); ?> </a>
                <ul class="sub-menu">
                    
                    <?php $__currentLoopData = $course_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if( url($course_item['path_url'])  === Request::url()): ?>
                            <li class="sub-menu-item active"><a href="<?php echo e(url($course_item['path_url'])); ?>"><?php echo e($course_item['path_name']); ?></a></li>
                        <?php else: ?>
                            <li class="sub-menu-item"><a href="<?php echo e(url($course_item['path_url'])); ?>"><?php echo e($course_item['path_name']); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </ul>
           </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
