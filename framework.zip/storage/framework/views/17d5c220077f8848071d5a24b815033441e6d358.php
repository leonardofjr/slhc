<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/backend/services/subpages/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <h2><?php echo e(\Request::route()->getName()); ?></h2>
    <form action="/services" method="POST">
        <?php echo e(csrf_field()); ?>


        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="service_name">Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control <?php echo e($errors->has('service_name') ? ' is-invalid' : ''); ?>" id="service_name" name="service_name" value="<?php echo e(old('service_name')); ?>"  placeholder="Enter name">
                 <?php if($errors->has('service_name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('service_name')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="slug">Slug</label>
            <div class="col-sm-10">
                <input type="text" class="form-control <?php echo e($errors->has('slug') ? ' is-invalid' : ''); ?>" id="slug" name="slug" value="<?php echo e(old('slug')); ?>"  placeholder="chinese-medicine">
                    <?php if($errors->has('slug')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('slug')); ?></strong>
                        </span>
                     <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="service_duration">Duration</label>
            <div class="col-sm-4">
                <select type="dropdown" class="form-control <?php echo e($errors->has('service_duration') ? ' is-invalid' : ''); ?>" id="service_duration" name="service_duration"  placeholder="Hour">
                    <option value="" selected> Choose...</option>
                    <option value="15" <?php echo e(old('service_duration') == "15"  ? "selected" : ""); ?>>15min</option>
                    <option value="30" <?php echo e(old('service_duration') == "30"  ? "selected" : ""); ?>>30min</option>
                    <option value="60" <?php echo e(old('service_duration') == "60"  ? "selected" : ""); ?>>60min</option>
                </select>
                <?php if($errors->has('service_duration')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('service_duration')); ?></strong>
                    </span>
                    <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="service_price">Price</label>
            <div class="col-sm-10">
                <input type="number" class="form-control <?php echo e($errors->has('service_price') ? ' is-invalid' : ''); ?>" id="service_price" name="service_price" value="<?php echo e(old('service_price')); ?>"  placeholder="20.00">
                 <?php if($errors->has('service_price')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('service_price')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="short_description">Short Description</label>
            <div class="col-sm-10">
                <textarea class="form-control <?php echo e($errors->has('short_description') ? ' is-invalid' : ''); ?>" id="short_description" name="short_description" value="<?php echo e(old('short_description')); ?>"  placeholder="Enter a short description"><?php echo e(old('short_description')); ?></textarea>
                 <?php if($errors->has('short_description')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('short_description')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="detailed_description">Detailed Description</label>
            <div class="col-sm-10">
                <textarea class="form-control <?php echo e($errors->has('detailed_description') ? ' is-invalid' : ''); ?>" id="detailed_description" name="detailed_description"   placeholder="Enter a description"><?php echo e(old('detailed_description')); ?></textarea>
                 <?php if($errors->has('detailed_description')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('detailed_description')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>

            <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'short_description' );
                CKEDITOR.replace( 'detailed_description' );
            </script>         
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>