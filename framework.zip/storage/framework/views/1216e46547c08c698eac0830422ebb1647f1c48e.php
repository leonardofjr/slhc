<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/components/schedule.blade.php */ ?>
<table class="table table-sm">
    <tr>
        <th>Day</th>
        <th>Start</th>
        <th>End</th>
    </tr>
<?php $__currentLoopData = $hours_of_operation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>   
    <td><?php echo e(jddayofweek($item->day, 2)); ?></td>
    <td><?php echo e(($item->start) ? date("h:i A", strtotime($item->start)) : "CLOSED"); ?></td>
    <td><?php echo e(($item->end) ? date("h:i A", strtotime($item->end)) : "CLOSED"); ?></td>
</tr> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
