<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/layouts/page.blade.php */ ?>
<!DOCTYPE html><?php $url = URL::to("/");?>

<html>

    <head>
            <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </head>

    <body>

        <header>

                <?php echo $__env->make('frontend.components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('frontend.components.jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </header>

        <main>
            <div class="page-title primary-bg-color">
                <h2 class="text-center m-0 p-0"><?php echo e(\Request::route()->getName()); ?></h2>
            </div>
            <div id="app" class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <h4 class="text-center">MENU</h4>
                        <app></app>
                    </div>
                    <div class="col-sm-9">
                        <router-view :key="$route.fullPath"></router-view>
                    </div>
                </div>
            </div>
        </main>

        <footer>

                <?php echo $__env->make('frontend.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </footer>

    </body>

    <script src= "https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

    <script src= "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script src="/dist/scripts/scripts.js"></script>

</html>