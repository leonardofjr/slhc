<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/backend/settings/settings_page.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<h2><?php echo e(\Request::route()->getName()); ?></h2>
<form action="/settings" method="POST">    
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="_method" value="put" />
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="business_name">Business Name</label>
            <div class="col-sm-10">
            <input type="text" value="<?php echo e($data->business_name); ?>" class="form-control <?php echo e($errors->has('business_name') ? ' is-invalid' : ''); ?>" id="business_name" name="business_name" placeholder="John">
            <?php if($errors->has('business_name')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('business_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="business_phone">Business Phone</label>
            <div class="col-sm-10">
                <input type="text"  value="<?php echo e($data->business_phone); ?>"  class="form-control <?php echo e($errors->has('business_phone') ? ' is-invalid' : ''); ?>" id="business_phone" name="business_phone" placeholder="Doe">
               <?php if($errors->has('business_phone')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('business_phone')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
      
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="business_email">Business Email</label>
            <div class="col-sm-10">
                <input type="text"  value="<?php echo e($data->business_email); ?>"  class="form-control <?php echo e($errors->has('business_email') ? ' is-invalid' : ''); ?>" id="business_email" name="business_email" placeholder="Doe">
                <?php if($errors->has('business_email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('business_email')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
        <div class="my-4">
        <h3>Hours of Operation</h2>
        <table class="table">
        <tr>
            <th>Day</th>
            <th>Open</th>
            <th>Close</th>
        </tr>
        <?php $__currentLoopData = $hoursOfOperation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(jddayofweek($item->day, 1)); ?></td>
                <td><input type="time" value="<?php echo e($item->start); ?>" name="start[]"></td>
                <td><input type="time" value="<?php echo e($item->end); ?>" name="end[]"></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
</form>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>