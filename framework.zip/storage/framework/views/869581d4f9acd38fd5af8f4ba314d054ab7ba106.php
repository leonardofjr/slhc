<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/backend/users/subpages/create_user_page.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <h2><?php echo e(\Request::route()->getName()); ?></h2>
    <form action="/api/users" method="POST">
        <input type="hidden" name="_method" value="put" />

        <div class="form-group row">
         <label for="fname" class="col-sm-2 col-form-label text-md-right"><?php echo e(__('First Name')); ?></label> 
            <div class="col-sm-10">
                <input id="fname" type="text" class="form-control<?php echo e($errors->has('fname') ? ' is-invalid' : ''); ?>" name="fname"  required autofocus>
            </div>
            <?php if($errors->has('fname')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('fname')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
       

        <div class="form-group row">
         <label for="lname" class="col-sm-2 col-form-label text-md-right"><?php echo e(__('Last Name')); ?></label> 
            <div class="col-sm-10">
                <input id="lname" type="text" class="form-control<?php echo e($errors->has('lname') ? ' is-invalid' : ''); ?>" name="lname"  required autofocus>
            </div>
            <?php if($errors->has('lname')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('lname')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
       

        <div class="form-group row">
         <label for="email" class="col-sm-2 col-form-label text-md-right"><?php echo e(__('Email')); ?></label> 
            <div class="col-sm-10">
                <input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" required autofocus>
            </div>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <table class="table">
            <tr>
                <th scope="col">Admin</th>
                <th scope="col">User</th>
                <th scope="col">Visitor</th>
            </tr>
            <td>
            <input type="checkbox" name="role_admin"></td>
                <td>
                 <input type="checkbox" name="role_user"></td>
                 <td>
                <input type="checkbox" name="role_visitor"></td>
        </table>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>