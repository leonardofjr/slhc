<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/backend/posts/subpages/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <h2><?php echo e(\Request::route()->getName()); ?></h2>
    <form action="/create_post" method="POST">
        <?php echo e(csrf_field()); ?>


        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="title">Title</label>
            <div class="col-sm-10">
                <input type="text" class="form-control <?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" id="title" name="title" value="<?php echo e(old('title')); ?>">
                 <?php if($errors->has('title')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('title')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="content">Content</label>
            <div class="col-sm-10">
                <textarea class="form-control <?php echo e($errors->has('content') ? ' is-invalid' : ''); ?>" id="content" name="content" value="<?php echo e(old('content')); ?>"  placeholder="Enter a short description"><?php echo e(old('content')); ?></textarea>
                 <?php if($errors->has('content')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('content')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>

       <div class="form-check">
            <input class="form-check-input " type="checkbox" id="visible" name="visible">
            <label class="form-check-label" for="visible">
                Visible
            </label>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>

            <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'content' );
            </script>         
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>