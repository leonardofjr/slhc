<?php /* C:\wamp64\www\html\sacred_light_healing_centre\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>
<?php echo e($slot); ?>

