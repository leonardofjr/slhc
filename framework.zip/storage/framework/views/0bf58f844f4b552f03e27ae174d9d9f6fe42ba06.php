<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/backend/posts/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
        <h2><?php echo e(\Request::route()->getName()); ?></h2><a class="btn btn-primary" href="<?php echo e(route("Create Post")); ?>">Add Post</a>

        <table class="table">
        <thead>
        <tr>
        <th scope="col">id</th>
        <th scope="col">Title</th>
        <th scope="col">Author</th>
        <th scope="col">Status</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
        </tr>
        </thead>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tbody>
        <tr>
                <th scope="row"><?php echo e($item->author_id); ?></th>
                <td><?php echo e($item->title); ?></td>
                <td><?php echo e(User::findOrFail($item->author_id)); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td><a href="/post/<?php echo e($item->id); ?>"><i class="fas fa-edit"></i></a></td>
                <td>
                <form action="/post/<?php echo e($item->id); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="delete" />
                                <button type="submit" class="far fa-trash-alt"></button>
                        </form>
                </td>
        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>