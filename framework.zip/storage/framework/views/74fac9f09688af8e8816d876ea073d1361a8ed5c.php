<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/pages/subpages/treatments/treatment.blade.php */ ?>
<?php $__env->startSection('title', 'Treatments - Sacred Light Healing Centre'); ?>
<?php $__env->startSection('content'); ?>
<h2><?php echo e($data->service_name); ?></h2>
<div>
    <?php echo e($data->detailed_description); ?>

</div>
<div>
    $<?php echo e($data->service_price); ?> <?php echo e($data->duration); ?>mins
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>