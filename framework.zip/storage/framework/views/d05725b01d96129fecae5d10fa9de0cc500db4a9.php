<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/frontend/components/map.blade.php */ ?>
<div class="mt-5" id="map"></div>