<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/emails/book.blade.php */ ?>
<?php $__env->startComponent('mail::message'); ?>
#This message is from our book now form at http://sacredlighthealing.ca

<strong>Name:</strong> <?php echo e($data['name']); ?> <br>
<strong>Phone:</strong> <?php echo e($data['phone']); ?> <br>
<strong>Email:</strong> <?php echo e($data['email']); ?> <br>
<strong>Service of interest:</strong>
<ul>
    <?php $__currentLoopData = $data['interests']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <li> <?php echo e($item); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<strong>Date:</strong> <?php echo e($data['date']); ?> <br>

<strong>Message:</strong> <?php echo e($data['message']); ?>


<?php echo $__env->renderComponent(); ?>