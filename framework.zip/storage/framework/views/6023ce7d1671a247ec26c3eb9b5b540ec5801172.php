<?php /* C:\wamp64\www\html\sacred_light_healing_centre\resources\views/layouts/contact.blade.php */ ?>
<!DOCTYPE html><?php $url = URL::to("/");?>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <header>
                <?php echo $__env->make('frontend.components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('frontend.components.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>
        <section class="container main-wrapper">
            <div class="row">
          
                <aside class="d-none d-md-block col-md-4 contact-sidebar">
                    <h3>Contact Us</h3>
                      <?php echo $__env->make('frontend.pages.partials.contact-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </aside>
                  
                <main class="col-12 col-sm-12 col-md-8 col-lg-8">
                    <h2>Let’s Get in Touch</h2>
                    <div class="content">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </main>
            </div>
         </section>
        <footer>
                <?php echo $__env->make('frontend.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
    </body>
    <script src='https://www.google.com/recaptcha/api.js'></script>

    <script src= "https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src= "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="/dist/scripts/scripts.js"></script>
    <script async defer
src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('GOOGLE_MAP_API_KEY')); ?>&callback=initMap">
    </script>
</html>